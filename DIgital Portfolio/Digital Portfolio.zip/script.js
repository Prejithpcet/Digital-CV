$(document).ready(function () {
  $("#ripple-profile").ripples({
    resolution: 512,
    dropRadius: 10,
  });
});
